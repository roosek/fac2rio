data:extend({
	{
		type = "int-setting",
    minimum_value = "1",
		name = "orphan-finder-search-range",
		setting_type = "runtime-global",
		default_value = 100
	}
})