script.on_init(function()
	local force = game.forces.player

    -- research technologies
    force.technologies["advanced-electronics"].researched = true
    force.technologies["advanced-electronics-2"].researched = true
    force.technologies["heavy-armor"].researched = true
    force.technologies["modular-armor"].researched = true
    force.technologies["automation"].researched = true
    force.technologies["automation-2"].researched = true
    force.technologies["automobilism"].researched = true
    force.technologies["battery"].researched = true
    force.technologies["battery-equipment"].researched = true
    force.technologies["character-logistic-slots-1"].researched = true
    force.technologies["character-logistic-trash-slots-1"].researched = true
    force.technologies["construction-robotics"].researched = true
    force.technologies["electric-energy-distribution-1"].researched = true
    force.technologies["electric-engine"].researched = true
    force.technologies["electronics"].researched = true
    force.technologies["energy-shield-equipment"].researched = true
    force.technologies["engine"].researched = true
    force.technologies["fluid-handling"].researched = true
    force.technologies["flying"].researched = true
    force.technologies["fusion-reactor-equipment"].researched = true
    force.technologies["logistic-robotics"].researched = true
    force.technologies["logistic-system"].researched = true
    force.technologies["logistics"].researched = true
    force.technologies["military"].researched = true
    force.technologies["modules"].researched = true
    force.technologies["oil-processing"].researched = true
    force.technologies["personal-roboport-equipment"].researched = true
    force.technologies["plastics"].researched = true
    force.technologies["power-armor"].researched = true
    force.technologies["robotics"].researched = true
    force.technologies["solar-panel-equipment"].researched = true
    force.technologies["speed-module"].researched = true
    force.technologies["steel-processing"].researched = true
    force.technologies["stone-walls"].researched = true
    force.technologies["sulfur-processing"].researched = true
    force.technologies["toolbelt"].researched = true
    force.technologies["turrets"].researched = true

end)

script.on_event(defines.events.on_player_created, function(event)
  local player = game.players[event.player_index]

    -- set quickbar slots
    local inventory = player.get_inventory(defines.inventory.player_quickbar)
		inventory.clear()
		inventory.set_filter(1,"transport-belt")
		inventory.set_filter(2,"underground-belt")
		inventory.set_filter(3,"splitter")
		inventory.set_filter(4,"medium-electric-pole")
		inventory.set_filter(5,"fast-inserter")
		inventory.set_filter(6,"assembling-machine-2")
		inventory.set_filter(7,"pipe")
		inventory.set_filter(8,"pipe-to-ground")
		inventory.set_filter(9,"deconstruction-planner")
		inventory.set_filter(10,"blueprint-book")
		inventory.set_filter(11,"electric-mining-drill")
		inventory.set_filter(12,"stone-furnace")
		inventory.set_filter(13,"pumpjack")
		inventory.set_filter(14,"big-electric-pole")
		inventory.set_filter(15,"long-handed-inserter")
		inventory.set_filter(16,"steel-chest")
		inventory.set_filter(17,"logistic-chest-active-provider")
		inventory.set_filter(18,"logistic-chest-passive-provider")
		inventory.set_filter(19,"logistic-chest-requester")
		inventory.set_filter(20,"logistic-chest-storage")

    -- insert power armor & fill items
    player.insert{name = "power-armor", count = 1}
      local armor = player.get_inventory(5)[1].grid
      armor.put({name = "fusion-reactor-equipment"})
      armor.put({name = "energy-shield-equipment"})
      armor.put({name = "energy-shield-equipment"})
      armor.put({name = "personal-roboport-equipment"})
      armor.put({name = "personal-roboport-equipment"})
      armor.put({name = "personal-roboport-equipment"})
      armor.put({name = "battery-equipment"})
      armor.put({name = "battery-equipment"})
      armor.put({name = "battery-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})
      armor.put({name = "solar-panel-equipment"})

    -- insert items to inventory

    -- weapons and axe
    player.insert{name = "steel-axe", count = 20}
    -- remove pistol
    player.get_inventory(defines.inventory.player_guns).find_item_stack("pistol").clear()
    player.insert{name = "submachine-gun", count = 1}
    player.insert{name = "firearm-magazine", count = 90}
    player.insert{name = "shotgun", count = 1}
    player.insert{name = "shotgun-shell", count = 100}

    player.insert{name = "repair-pack", count = 100}
    player.insert{name = "radar", count = 10}
    player.insert{name = "gun-turret", count = 10}
    player.insert{name = "firearm-magazine", count = 200}

    player.insert{name = "car", count = 1}
    player.insert{name = "coal", count = 100}

    player.insert{name = "transport-belt", count = 800}
    player.insert{name = "underground-belt", count = 100}
    player.insert{name = "splitter", count = 50}

    player.insert{name = "medium-electric-pole", count = 200}
    player.insert{name = "big-electric-pole", count = 50}

    player.insert{name = "fast-inserter", count = 400}
    player.insert{name = "long-handed-inserter", count = 50}

    player.insert{name = "stone-furnace", count = 100}
    player.insert{name = "assembling-machine-2", count = 100}
    player.insert{name = "chemical-plant", count = 20}
    player.insert{name = "lab", count = 10}
    player.insert{name = "oil-refinery", count = 10}
    player.insert{name = "storage-tank", count = 5}

    player.insert{name = "construction-robot", count = 80}
    player.insert{name = "logistic-robot", count = 500}
    player.insert{name = "roboport", count = 10}

    player.insert{name = "steel-chest", count = 50}
    player.insert{name = "logistic-chest-passive-provider", count = 100}
    player.insert{name = "logistic-chest-active-provider", count = 50}
    player.insert{name = "logistic-chest-storage", count = 50}
    player.insert{name = "logistic-chest-requester", count = 100}

    player.insert{name = "pumpjack", count = 10}
    player.insert{name = "electric-mining-drill", count = 50}

    player.insert{name = "offshore-pump", count = 1}
    player.insert{name = "steam-engine", count = 40}
    player.insert{name = "boiler", count = 20}
    player.insert{name = "pipe", count = 100}
    player.insert{name = "pipe-to-ground", count = 50}
    player.insert{name = "burner-inserter", count = 60}

    player.insert{name = "iron-plate", count = 392}
    player.insert{name = "copper-plate", count = 200}
    player.insert{name = "steel-plate", count = 200}
    player.insert{name = "iron-gear-wheel", count = 200}
    player.insert{name = "electronic-circuit", count = 200}
    player.insert{name = "advanced-circuit", count = 200}

end)

script.on_event(defines.events.on_player_respawned, function(event)
  local player = game.players[event.player_index]

  -- insert armor after respawn
  player.insert{name = "power-armor", count = 1}
    local armor = player.get_inventory(5)[1].grid
    armor.put({name = "fusion-reactor-equipment"})
    armor.put({name = "energy-shield-equipment"})
    armor.put({name = "energy-shield-equipment"})
    armor.put({name = "personal-roboport-equipment"})
    armor.put({name = "personal-roboport-equipment"})
    armor.put({name = "personal-roboport-equipment"})
    armor.put({name = "battery-equipment"})
    armor.put({name = "battery-equipment"})
    armor.put({name = "battery-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})
    armor.put({name = "solar-panel-equipment"})

  -- insert weapons & car
  player.insert{name = "steel-axe", count = 20}
  -- remove pistol
  player.get_inventory(defines.inventory.player_guns).find_item_stack("pistol").clear()
  player.insert{name = "submachine-gun", count = 1}
  player.insert{name = "firearm-magazine", count = 90}
  player.insert{name = "shotgun", count = 1}
  player.insert{name = "shotgun-shell", count = 100}
  
  player.insert{name = "car", count = 1}
  player.insert{name = "coal", count = 100}

end)
