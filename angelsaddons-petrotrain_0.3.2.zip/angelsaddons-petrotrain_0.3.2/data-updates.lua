if angelsmods.logistics then
	require("prototypes.petro-category")
	data.raw["item-with-entity-data"]["petro-locomotive-1"].subgroup = "angels-petrotrain"
	data.raw["item-with-entity-data"]["petro-tank1"].subgroup = "angels-petrotrain"
	data.raw["item-with-entity-data"]["petro-tank2"].subgroup = "angels-petrotrain"
end

