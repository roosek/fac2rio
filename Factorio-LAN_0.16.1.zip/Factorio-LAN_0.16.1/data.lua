ANTENNA_SIGNAL_SLOTS = 5

require("prototypes.entities")
-- require("prototypes.gui")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technology")