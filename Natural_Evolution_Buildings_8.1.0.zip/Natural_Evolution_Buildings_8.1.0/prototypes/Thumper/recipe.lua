data:extend({
 

	--- Thumper
	{
		type = "recipe",
		name = "Thumper",
        energy_required = 10,
		enabled = false,
		ingredients =
        {
            {"Building_Materials", 1},
		--	{"iron-plate", 1},
        },
		result = "Thumper"
	}, 

	
})