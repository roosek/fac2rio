data:extend(
{
  {
    type = "item-subgroup",
    name = "bob-energy-boiler",
    group = "production",
    order = "b-a"
  },
  {
    type = "item-subgroup",
    name = "bob-energy-steam-engine",
    group = "production",
    order = "b-b"
  },
  {
    type = "item-subgroup",
    name = "bob-energy-solar-panel",
    group = "production",
    order = "b-c"
  },
  {
    type = "item-subgroup",
    name = "bob-energy-accumulator",
    group = "production",
    order = "b-d"
  },
}
)

