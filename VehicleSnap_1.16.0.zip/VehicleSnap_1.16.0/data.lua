data:extend({
  {
    type = "custom-input",
    name = "VehicleSnap-toggle",
    key_sequence = "SHIFT + V",
    consuming = "script-only"
  }
})
